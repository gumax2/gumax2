# O que realmente resta (versão 1.2.0, 30/10/2026)

## Já resolvido nesta etapa
- Base do painel recebida e integrada. A tabela abaixo mostra o que a base trouxe e como o módulo usa cada item.

| Item da base | Como o módulo trata |
|---|---|
| Fonte dos avisos | `client_plans.due_date` (o `clients.due_date` legado é ignorado) |
| Excluídos | `client_exclusions` |
| Valores | `price_cents` (total do ciclo) |
| Ciclo | `months` 1/3/6/12 |
| IDs | texto |
| Login | sessão do painel reaproveitada; módulo **sem credencial própria**, lê o config privado do painel |
| Menu | link inserido com conferência, cópia e reversão |
| Caminho | painel em `/home1/gust1922/gmaxcanais.com.br/painel/`; biblioteca em `/home1/gust1922/gmax-renovacoes` |
| `.htaccess` | diagnóstico + liberação mínima só dos 3 arquivos, com cópia e reversão |

- 98 testes executados em bancos **descartáveis**, sem nenhum pulado. Incluem:
  - o `api.php` real: login, CSRF, logout, expiração, renovação por `entry`, `delete_client` e regressão do `action=data`;
  - **Apache 2.4.58 real** com 4 formatos de `.htaccess`;
  - o teste visual no **Chromium**.
  Resultado em `TESTES_RESULTADO.md`.
- Três rodadas de revisão de segurança, sem achado de gravidade alta. A 3ª, sobre o `.htaccess`, foi feita pelo coordenador porque o agente parou por limite de uso. Correções aplicadas e cobertas por testes (`REVISAO_SEGURANCA.md`).

## Para INSTALAR (depende de você)
1. **Revisão do pacote** (Codex/você): ZIP `dist/GMAX_Renovacoes_1.2.0_incremental.zip` e a branch `claude/gmax-whatsapp-renewal-reminders-poplk0`.
2. **Backup SQL completo** do banco `gust1922_gmaxpainel` + cópia dos `.htaccess` + ZIP da pasta `/home1/gust1922/gmaxcanais.com.br/painel`, guardados fora do servidor e fora do Git (`BACKUP_E_RECUPERACAO.md`, parte A).
3. **Conferir no servidor** que o caminho do config privado do painel é o mesmo do `api.php` (`/home1/gust1922/gmax-painel/private/config.php`) e que o PHP da linha de comando é 8.0+.
4. Seguir `INSTALACAO.md`. O passo 5 (comparativo de integridade antes/depois) é a **prova na produção**. Até lá, a preservação só foi demonstrada em banco descartável, com a estrutura da base de 15/10, que pode diferir da produção.
5. **`.htaccess`:** rodar `htaccess verificar` e `verificar-http` (`HTACCESS.md`).
   - Se a regra antiga bloquear os 3 arquivos, aplicar a liberação mínima.
   - Formato desconhecido: me enviar o `.htaccess` (sem senhas). O conteúdo real ainda não foi visto; só os 4 formatos comuns foram testados no Apache.
6. Aplicar o link do menu com `menu verificar` e depois `menu aplicar`. Se o `index.html` de produção estiver diferente da base, o comando não altera nada; nesse caso me envie o arquivo.

## Para ATIVAR a simulação
7. Revisar os textos na aba Configurações e marcar **Módulo ativo** (Modo continua **Simulação**). O simulado não envia nada e **não prova entrega**.
8. Registrar autorizações **reais** na aba Autorizações. Importar a carteira não autorizou ninguém.

## Para o ENVIO REAL (etapa futura, só com sua autorização expressa)
9. Escolher o caminho do número (`WHATSAPP_API.md` §2):
   - coexistência via parceiro (mantém o número e o app);
   - ou número novo direto na Cloud API.
   Se for um parceiro com endpoint próprio, é preciso escrever o conector dele.
10. Conta Meta Business + WABA + forma de pagamento. Conferir a **tabela oficial de preços** (BRL).
11. Credenciais no `config.php` do módulo, **somente no servidor**:
    - `phone_number_id`
    - `waba_id`
    - token de Usuário do Sistema
    - App Secret
    - verify token
12. Cadastrar e aprovar os **6 modelos** (com a linha de descadastro no texto aprovado). Depois, preencher os nomes na aba.
13. Configurar o webhook `/painel/renovacoes-webhook.php`, campo `messages`. Se a pasta `/painel/` tiver senha HTTP (`AuthType Basic`), avise: a liberação automática do `.htaccess` não mexe nesse tipo de proteção.
14. Confirmar a chave Pix `gumaxskins@gmail.com` e as instruções na aba.
15. Modo Real com **"somente números de teste"** marcado → mensagem de teste para um contato **interno** → conferir *Aceito → Entregue → Lido* no Histórico.
16. Só então desmarcar "somente números de teste".

## Limitações conhecidas (não bloqueiam)
- A base é a entrega de 15/10, não um download da produção. Diferenças na produção aparecem no `diagnostico`, no `menu verificar` e no comparativo de integridade. Em nenhum caso o módulo grava por cima.
- "Somente leitura" é garantido pelo código, não pelo banco: o usuário MySQL do painel pode gravar em tudo, e a hospedagem não permite permissão por tabela.
- Envio com resposta perdida fica **Resultado incerto** até a reconciliação. Reenviar, enviar manualmente ou mandar mensagem de teste são decisões suas e podem duplicar.
