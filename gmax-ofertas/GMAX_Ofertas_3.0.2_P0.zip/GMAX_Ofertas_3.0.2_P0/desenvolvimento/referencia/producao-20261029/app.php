<?php
declare(strict_types=1);
date_default_timezone_set('America/Sao_Paulo');
const STOR = __DIR__.'/storage';
function db(): PDO { if(!is_dir(STOR)) mkdir(STOR,0700,true); $p=new PDO('sqlite:'.STOR.'/offers.sqlite');$p->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);$p->exec('PRAGMA busy_timeout = 5000');$p->exec('CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, password_hash TEXT NOT NULL)');$p->exec('CREATE TABLE IF NOT EXISTS offers (item_id TEXT PRIMARY KEY,title TEXT NOT NULL,price TEXT NOT NULL,shop TEXT,commission_rate TEXT,commission TEXT,original_url TEXT NOT NULL,affiliate_url TEXT NOT NULL,status TEXT NOT NULL DEFAULT "pendente",created_at TEXT DEFAULT CURRENT_TIMESTAMP,sent_at TEXT)');$p->exec('CREATE TABLE IF NOT EXISTS slots (slot TEXT PRIMARY KEY,status TEXT NOT NULL,detail TEXT)');return $p; }
function h(string $s):string{return htmlspecialchars($s,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');}
function valid(string $url,string $domain):bool{$p=parse_url($url);return is_array($p)&&($p['scheme']??'')==='https'&&strtolower($p['host']??'')===$domain&&!isset($p['user'])&&!isset($p['pass'])&&isset($p['path'])&&$p['path']!=='/';}
function importFile(PDO $db,string $file):array { $f=fopen($file,'rb');if(!$f)throw new RuntimeException('Arquivo indisponível');$headers=fgetcsv($f,0,',','"','');if(!$headers)throw new RuntimeException('CSV vazio');$headers[0]=preg_replace('/^\xEF\xBB\xBF/','',$headers[0]);$req=['Item Id','Item Name','Price','Commission Rate','Commission','Product Link','Offer Link'];foreach($req as $c)if(!in_array($c,$headers,true))throw new RuntimeException('Coluna ausente: '.$c);$stmt=$db->prepare('INSERT OR IGNORE INTO offers(item_id,title,price,shop,commission_rate,commission,original_url,affiliate_url) VALUES(?,?,?,?,?,?,?,?)');$ok=0;$bad=0;while(($cells=fgetcsv($f,0,',','"',''))!==false){ if(count($cells)!==count($headers)){$bad++;continue;}$r=array_combine($headers,$cells);$id=trim($r['Item Id']);$orig=trim($r['Product Link']);$aff=trim($r['Offer Link']);$price=trim($r['Price']);if(!preg_match('/^\d+$/',$id)||!valid($orig,'shopee.com.br')||!valid($aff,'s.shopee.com.br')||!str_ends_with(parse_url($orig,PHP_URL_PATH)?:'','/'.$id)||!preg_match('/^\d+[,.]\d{2}$/',$price)){$bad++;continue;}$stmt->execute([$id,trim($r['Item Name']),$price,trim($r['Nome da loja']??''),trim($r['Commission Rate']),trim($r['Commission']),$orig,$aff]);$ok+=$stmt->rowCount();}fclose($f);return [$ok,$bad];}
function message(array $r):string{return "🛍️ *GMAX OFERTAS | SHOPEE*\n\n".$r['title']."\n💰 Preço anunciado: R$ ".$r['price']."\n🛒 ".$r['affiliate_url']."\n\nPreço sujeito a alteração na loja. Link de afiliado GMAX.";}
function slot(PDO $db,bool $send=false):string { $now=new DateTimeImmutable('now',new DateTimeZone('America/Sao_Paulo'));$clock=$now->format('H:i');$times=['08:00','10:00','12:00','15:00','18:00','20:00'];if(!in_array($clock,$times,true))return 'Fora da janela programada';$key=$now->format('Y-m-d H:i');$db->beginTransaction();try{$sel=$db->prepare('SELECT 1 FROM slots WHERE slot=?');$sel->execute([$key]);if($sel->fetchColumn()){$db->commit();return 'Janela já processada';}$offer=$db->query('SELECT * FROM offers WHERE status="pendente" ORDER BY created_at,item_id LIMIT 1')->fetch(PDO::FETCH_ASSOC);if(!$offer){$db->commit();return 'Fila vazia';}if(!$send){$db->commit();return 'PRÉVIA: '.message($offer);} // Fechado por padrão. Nenhuma interface web oferece ativação.
 if(getenv('GMAX_TELEGRAM_ENABLED')!=='true'||is_file('/opt/gmax-ofertas/private/v3-requests/telegram.pause')){ $db->commit();return 'Bloqueado: envios desativados';}

$configFile = '/home1/gust1922/gmax-secrets/telegram.php';

if (!is_readable($configFile)) {
    $db->commit();
    return 'Bloqueado: configuração privada indisponível';
}

$config = require $configFile;

$token = $config['token'] ?? '';
$chat = $config['chat_id'] ?? '';

if ($chat !== '-1004443626419') {
    $db->commit();
    return 'Bloqueado: destino não autorizado';
}
if(!$token||!$chat){$db->commit();return 'Bloqueado: destino ou token ausente';}
 $db->prepare('INSERT INTO slots(slot,status,detail) VALUES(?,"tentativa","pendente de reconciliação")')->execute([$key]);$db->commit();
 $payload=http_build_query(['chat_id'=>$chat,'text'=>str_replace('*','',message($offer)),'disable_web_page_preview'=>'true']);$ctx=stream_context_create(['http'=>['method'=>'POST','header'=>"Content-Type: application/x-www-form-urlencoded\r\n",'content'=>$payload,'timeout'=>20,'ignore_errors'=>true]]);$raw=@file_get_contents('https://api.telegram.org/bot'.$token.'/sendMessage',false,$ctx);$data=$raw?json_decode($raw,true):null;
 if(!is_array($data)||!($data['ok']??false)){return 'Possível falha: verificar Telegram manualmente antes de reenviar';}
 $db->prepare('UPDATE offers SET status="enviado",sent_at=CURRENT_TIMESTAMP WHERE item_id=?')->execute([$offer['item_id']]);$db->prepare('UPDATE slots SET status="concluido",detail="Telegram confirmou" WHERE slot=?')->execute([$key]);return 'Mensagem enviada';
 }catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}}
